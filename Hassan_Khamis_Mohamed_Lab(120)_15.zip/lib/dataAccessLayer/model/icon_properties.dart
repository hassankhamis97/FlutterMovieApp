import 'package:flutter/material.dart';

class IconProperties {
  double width;
  Color iconColor;
  IconData favoIcon;

  IconProperties(this.width, this.iconColor, this.favoIcon);

}