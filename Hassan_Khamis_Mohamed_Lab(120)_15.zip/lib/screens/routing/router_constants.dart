const String MovieListViewRoute = '/';
const String MovieDetailsViewRoute = 'movieDetails';