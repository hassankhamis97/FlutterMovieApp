import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlab3/screens/movie_details/movie_details.dart';
import 'package:flutterlab3/screens/movie_list/structurePageState.dart';
import 'package:flutterlab3/screens/routing/router.dart' as router;
import 'package:flutterlab3/screens/routing/router_constants.dart';

class MovieList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        routes: {
          MovieDetailsViewRoute : (context) => MovieDetails(),
        },
      title: 'Movies',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: StructurePage(),
      onGenerateRoute: router.generateRoute
    );
  }
}