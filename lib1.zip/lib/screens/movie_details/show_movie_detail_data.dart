//import 'package:flutter/cupertino.dart';
//import 'package:flutter/material.dart';
//class ShowMovieDetailData extends StatefulWidget {
//  ShowMovieDetailDataState createState() => ShowMovieDetailDataState();
//}
//
//class ShowMovieDetailDataState extends State<ShowMovieDetailData>
//{
//  @override
//  Widget build(BuildContext context) {
//    final myImage = Hero(
//      child: Container(
//        width: MediaQuery
//            .of(context)
//            .size
//            .width,
//        height: MediaQuery.of(context).size.height / 2,
//        decoration: new BoxDecoration(
//          image: new DecorationImage(image: AssetImage(
//            movie.
//          ))
//        ),
//      ),
//    );
//    // TODO: implement build
//    return Column(
//      children: <Widget>[
//        Container(
//          height: 600.0,
//          child: ClipRRect(
//            borderRadius: BorderRadius.circular(8.0),
//            child: Image.network(movie.image),
//          ),
//        ),
//      ],
//    );
//  }
//
//}