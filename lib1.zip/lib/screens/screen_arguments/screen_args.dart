class ScreenArguments {
  final int id;
  final String posterPath;

  ScreenArguments(this.id, this.posterPath);
}