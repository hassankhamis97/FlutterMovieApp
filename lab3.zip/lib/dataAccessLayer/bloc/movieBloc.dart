import 'package:flutterlab3/dataAccessLayer/model/movie.dart';
import 'package:flutterlab3/dataAccessLayer/repository/movieReopository.dart';
import 'package:shared_preferences/shared_preferences.dart';

class MovieBloc {
   Set<String> _saved = <String>{};
  MovieBloc._privateConstructor();
  static MovieBloc _instance = MovieBloc._privateConstructor();
   void saveMovie(String value) {
     _saved.add(value);
     addStringToSF(value);
   }
   void deleteMovie(String value) {
     _saved.remove(value);
     addStringToSF(value);
   }

   factory MovieBloc() {
    return _instance;
  }
  Future<List<Movie>> movieDisplay () async
  {
    List<Movie> movies = await MovieRepository().movies();
    return movies;
  }

  bool getSavedStatus(String title) {
    return _saved.contains(title);
  }
   int getCount(){
     return _saved.length;
   }
//
   Future<bool> getSavedFavouiteFromPref() async{
     SharedPreferences prefs = await SharedPreferences.getInstance();
     List<String> data = prefs.getStringList("Favourite");
     _saved.clear();
     for(int i = 0 ; i < data.length ; i++) {
         _saved.add(data[i]);
     }
     return true;
  }
  addStringToSF(String title) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setStringList("Favourite", _saved.toList());
    prefs.setString(title, title);
  }
}