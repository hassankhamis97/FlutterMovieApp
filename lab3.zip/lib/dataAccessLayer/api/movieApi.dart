
import 'package:flutterlab3/dataAccessLayer/clientHttp.dart';
import 'package:flutterlab3/dataAccessLayer/model/movie.dart';


class MovieApi
{
  Future<List<Movie>> getMovies() async {
    var movies = await HttpClient().getMovies();
    return movies;

  }
}