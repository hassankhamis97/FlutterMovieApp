
import 'package:flutterlab3/dataAccessLayer/api/movieApi.dart';
import 'package:flutterlab3/dataAccessLayer/model/movie.dart';

class MovieRepository
{
  Future<List<Movie>> movies() async => await MovieApi().getMovies();
}