import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlab3/screens/movie_details/show_movie_detail_data.dart';
import 'package:flutterlab3/screens/movie_list/MovieListView.dart';
class MovieDetailStructureState extends State<MovieDetailStructure> {
  @override
  Widget build(BuildContext context) {

    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text('Movie Detail'),
        backgroundColor: Color.fromARGB(255, 255, 0, 0),
      ),
      body: Center(
        child: ShowMovieDetailData(),
      ),
    );
  }

}
class MovieDetailStructure extends StatefulWidget {
  MovieDetailStructureState createState() => MovieDetailStructureState();
}
