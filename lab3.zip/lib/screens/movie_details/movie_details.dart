import 'package:flutter/material.dart';
import 'package:flutterlab3/screens/movie_list/structurePageState.dart';
import 'package:flutterlab3/screens/routing/router.dart' as router;

import 'movie_detail_structure.dart';

class MovieDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Movie Detail',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: MovieDetailStructure(),
        onGenerateRoute: router.generateRoute
    );
  }
//  Widget build(BuildContext context) {
//    return MaterialApp(
//      title: 'Lab 2',
//      theme: ThemeData(
//        primarySwatch: Colors.blue,
//      ),
//      home: StructurePage(),
//      onGenerateRoute: router.generateRoute
//    );
//  }
}
//
//class HomeView extends StatelessWidget {
//  @override
//  Widget build(BuildContext context) {
//    return Scaffold(
//      body: Center(child: Text('Home'),),
//    );
//  }
//}