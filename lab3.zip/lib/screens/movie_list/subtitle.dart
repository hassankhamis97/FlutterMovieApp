import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlab3/dataAccessLayer/model/movie.dart';

class Subtitle extends StatelessWidget
{
  Movie movie;
  Subtitle({@required this.movie});
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 5.0),
      height: 50,
      child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: movie.genreIds.length,
          itemBuilder: (context, index) {
            return Container(
              width: 100,
              child: Card(
                color: Colors.white,
                child: Container(
                  child: Center(
                      child: Text(
                        movie.genreIds[index].toString(),
                        style:
                        TextStyle(color: Colors.deepOrange, fontSize: 16.0),
                      )),
                ),
              ),
            );
          }),
    );
  }

}