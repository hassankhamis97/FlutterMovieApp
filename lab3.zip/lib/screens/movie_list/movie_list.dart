import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutterlab3/screens/movie_list/structurePageState.dart';
import 'package:flutterlab3/screens/routing/router.dart' as router;

class MovieList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      title: 'Movies',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: StructurePage(),
      onGenerateRoute: router.generateRoute
    );
  }
}